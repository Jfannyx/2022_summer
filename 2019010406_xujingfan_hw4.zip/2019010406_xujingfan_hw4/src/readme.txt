python 3.8.5
pytorch 1.12.0+cpu
django 4.0.6
bootstrap 3.4.1

第三方库：matplotlib
